//
//  ViewController.swift
//  localizacion
//
//  Created by 2020-1 on 10/9/19.
//  Copyright © 2019 ioslabv. All rights reserved.
//

import UIKit
import MapKit


class ViewController: UIViewController ,MKMapViewDelegate{

    
    @IBOutlet weak var mapa: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        mapa.delegate = self
        
        let inicio = CLLocationCoordinate2D(latitude: 19.3272501, longitude: -99.1845969)
        
        
        let destino = CLLocationCoordinate2D(latitude: 19.3248272, longitude: -99.1947808)

        let iniciopin = direccion(title: "El Olimpo", subtitle: "anexo", coordinate: inicio)
        
        
        let destinopin = direccion(title: "conta", subtitle: "al", coordinate: destino)
        
        
        mapa.addAnnotations([iniciopin, destinopin])
        
        //creacion de placemark
        
        let iniciopm = MKPlacemark(coordinate: inicio)
        let destinopm = MKPlacemark(coordinate: destino)
        
        //direccionrequest
        let direcciono = MKDirections.Request()
    
    direcciono.source = MKMapItem(placemark: iniciopm)
    direcciono.destination = MKMapItem(placemark: destinopm)
        direcciono.transportType = .walking
        
        let directions = MKDirections(request: direcciono)
        
        directions.calculate{  (response, error) in
            if let error = error {
                print(error.localizedDescription)
                return
            }
            
            
            guard let directionResponse = response else{
                return
            }
         
            let ruta = directionResponse.routes.first
            self.mapa.addOverlay(ruta!.polyline)
            let rect = ruta?.polyline.boundingMapRect
            
            //Me crea el rectangulo
            self.mapa.setRegion(MKCoordinateRegion(rect!), animated: true)
            
            
        }
        
        let inic = CLLocation(latitude: <#T##CLLocationDegrees#>, longitude: <#T##CLLocationDegrees#>)
        let desti = CLLocation(latitude: <#T##CLLocationDegrees#>, longitude: <#T##CLLocationDegrees#>)
        
        let distancia = inic.distance(from:desti)
        print (distancia)
        
        let distanciafor = String(format: "Distancia %0.2metros", distancia)
        print("\(distanciafor)")
        
        
        
        
        
    }

     func mapView(_ mapView: MKMapView, rendererFor overlay : MKOverlay) ->
    MKOverlayRenderer{
        let linea = MKPolylineRenderer (overlay: overlay)
        linea.strokeColor = .red
        linea.lineWidth = 4.0
        return linea
    
    
    }
    
    

}

