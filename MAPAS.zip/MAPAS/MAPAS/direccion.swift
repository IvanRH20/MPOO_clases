//
//  direccion.swift
//  MAPAS
//
//  Created by 2020-1 on 10/7/19.
//  Copyright © 2019 ioslabv. All rights reserved.
//

import UIKit
import MapKit


class Direccion : NSObject{
  var titulo : String
  var subtitulo : String

}
init
