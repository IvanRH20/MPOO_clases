//
//  ViewController.swift
//  MAPAS
//
//  Created by 2020-1 on 10/7/19.
//  Copyright © 2019 ioslabv. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit




class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let inicio = CLLocationCoordinate2D(latitude:24.819894,longitude:  -104.668824)
        let final = CLLocationCoordinate2D(latitude:24.023059,longitude:  -104.652279)
        
        let iniciofin = Direccion(titulo:)
        
        
        // Do any additional setup after loading the view.
    }


}

